# Gotomeeting for Franz
This is my personnal Franz recipe for Gotomeeting

### How to create your own Franz recipes:
* [Read the documentation](https://github.com/meetfranz/plugins)
